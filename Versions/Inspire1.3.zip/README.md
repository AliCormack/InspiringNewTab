# InspiringNewTab
A customisable new tab page which shows a gallery of content from website such as Behance, Artstation, etc

![Alt text](publication/screenshots/relevant.png?raw=true "Title")
